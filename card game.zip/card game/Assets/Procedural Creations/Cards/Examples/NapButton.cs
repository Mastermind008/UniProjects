﻿using UnityEngine;
using System.Collections;

public class NapButton : MonoBehaviour
{
	public string Message;

	void OnMouseDown()
	{
		transform.parent.gameObject.GetComponent<Nap>().OnButton(Message);

	}
}

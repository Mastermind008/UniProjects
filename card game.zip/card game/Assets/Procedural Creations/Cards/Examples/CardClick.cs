﻿using UnityEngine;
using System.Collections;

public class CardClick : MonoBehaviour {

    /*void OnMouseDown()
    {
        Card c = this.gameObject.GetComponent<Card>();
		//Debug.Log (c.Definition.Text +" of " +c.Definition.Symbol);
		//Nap.DoYourTurn (c);
		transform.parent.parent.gameObject.GetComponent<Nap>().DoYourTurn(c);

	}*/
}

﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Nap : MonoBehaviour {
	
	public CardDeck Deck;

	List<Card> player_1 = new List<Card>();
	List<Card> player_2 = new List<Card>();
	List<Card> player_3 = new List<Card>();
	List<Card> player_4 = new List<Card>();
	List<Card> SpareCard = new List<Card>();
	List<Card> OnPlay = new List<Card>();


	GameObject player1Wins;
	GameObject player2Wins;
	GameObject player3Wins;
	GameObject player4Wins;
	GameObject title;
	GameObject FarighCard;
	GameObject[] players;

	enum GameState
	{
		Invalid,
		Started,	
		Resolving,
		Player1Wins,
		player2Wins,
		player3Wins,
		player4Wins,
		NobodyWins,
		YourTurn,
		ComputerTurn,
	};

	LayerMask mask = -1;
	GameState state;
	int turn = 0;
	int highest = 0;
	string Symbol = "Spade";
	GameObject ButtonS;
	GameObject Deck_plane;
	Card LastCard;
	bool FirstTurn;
	int turnCount = 0;
	bool YourTurn = false;
	int won=0;
	// Use this for initialization
	void Start () {
		
		state = GameState.Invalid;
		Deck.Initialize ();

		title = this.transform.Find ("title").gameObject;
		player1Wins = this.transform.Find ("player1Wins").gameObject;
		player2Wins = this.transform.Find ("player2Wins").gameObject;
		player3Wins = this.transform.Find ("player3Wins").gameObject;
		player4Wins = this.transform.Find ("player4Wins").gameObject;

		player1Wins.SetActive (false);
		player2Wins.SetActive (false);
		player3Wins.SetActive (false);
		player4Wins.SetActive (false);

		players = new GameObject[4];
		players[0]= this.transform.Find ("player1").gameObject;
		players[1]= this.transform.Find ("player2").gameObject;
		players[2]= this.transform.Find ("player3").gameObject;
		players[3]= this.transform.Find ("player4").gameObject;
		for (int i = 0; i < 4; i++)
			players [i].SetActive (false);
		
		Deck_plane = this.transform.Find("deckPlane").gameObject;
		ButtonS = this.transform.Find ("ButtonS").gameObject;
		ButtonS.GetComponent<Renderer>().material.color = Color.red;
	}

	// Update is called once per frame
	void Update () {
		
		GameObject clickedGmObj = null;
		Card c;

		if (Input.GetKeyDown(KeyCode.F1))
		{
			OnStart();
		}

		if (Input.GetMouseButtonDown (0) && turn ==1) {

			Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
			RaycastHit hit;

			if (Physics.Raycast (ray, out hit)) {
			
				clickedGmObj = hit.transform.gameObject;
				c = clickedGmObj.GetComponent<Card> ();
				
				Debug.Log (c.Definition.Text + " of " + c.Definition.Symbol);
				DoYourTurn (c);
			}
		}
		
	}

	void ShowMessage(string msg)
	{
		if (msg == "player1")
		{
			player1Wins.SetActive(true);
			player2Wins.SetActive(false);
			player3Wins.SetActive(false);
			player4Wins.SetActive(false);
		}
		else if (msg == "Player2")
		{
			player1Wins.SetActive(false);
			player2Wins.SetActive(true);
			player3Wins.SetActive(false);
			player4Wins.SetActive(false);
		}
		else if (msg == "player3")
		{
			player1Wins.SetActive(false);
			player2Wins.SetActive(false);
			player3Wins.SetActive(true);
			player4Wins.SetActive(false);
		}
		else if(msg == "player4")
		{
			player1Wins.SetActive(false);
			player2Wins.SetActive(false);
			player3Wins.SetActive(false);
			player4Wins.SetActive(true);
		}
		else
		{
			player1Wins.SetActive(false);
			player2Wins.SetActive(false);
			player3Wins.SetActive(false);
			player4Wins.SetActive(false);
		}
	}



	void Clear()
	{
		foreach (Card c in player_1)
		{
			GameObject.DestroyImmediate(c.gameObject);
		}
		foreach (Card c in player_2)
		{
			GameObject.Destroy(c.gameObject);
		}
		foreach (Card c in player_3)
		{
			GameObject.Destroy(c.gameObject);
		}
		foreach (Card c in player_4)
		{
			GameObject.Destroy(c.gameObject);
		}
		player_1.Clear();
		player_2.Clear();
		player_3.Clear();
		player_4.Clear();
		Deck.Reset();
	}

	Vector3 GetDeckPosition()
	{
		return new UnityEngine.Vector3(0,0,0);
	}

	const float FlyTime = 0.3f;
	const float ShuffleTime = 0.2f;
	const float wait = 0.3f;

	IEnumerator OnStart()
	{
		
		if (state != GameState.Resolving)
		{
			ButtonS.SetActive (false);
			title.SetActive (false);

			state = GameState.Resolving;
			ShowMessage("");
			Clear();
			Deck.Shuffle();

			players [0].SetActive (true);
			for (int i = 0; i < 13; i++) 
			{
				DistributePlayer1 ();
				yield return new WaitForSeconds (wait);
			}

			players [1].SetActive (true);
			for (int i = 0; i < 13; i++) 
			{
				DistributePlayer2 ();
				yield return new WaitForSeconds (wait);
			}

			Deck_plane.transform.rotation = Quaternion.Euler(0,180,0);

			players [2].SetActive (true);
			for (int i = 0; i < 13; i++) 
			{
				DistributePlayer3 ();
				yield return new WaitForSeconds (wait);
			}

			players [3].SetActive (true);
			for (int i = 0; i < 13; i++) 
			{
				DistributePlayer4();
				yield return new WaitForSeconds (wait);
			}
			Deck_plane.SetActive (false);
			state = GameState.Started;

			yield return new WaitForSeconds (2.0f);
			startGame ();

			yield return new WaitForSeconds (1.5f); 
			StartCoroutine (nextTurn());

		}


	}

	void DistributePlayer1()
	{
		CardDef c1 = Deck.Pop();
		if (c1 != null)
		{
			GameObject newObj = new GameObject();
			newObj.name = "Card";
			Card newCard = newObj.AddComponent(typeof(Card)) as Card;
			newCard.Definition = c1;
			newObj.transform.parent = Deck.transform;
			BoxCollider bc = newObj.AddComponent<BoxCollider>() as BoxCollider;
			CardClick cc = newObj.AddComponent<CardClick> ();
			bc.center = new Vector3 (0, 0, 0);
			bc.size = new Vector3 (2, 3, 2);
			newCard.TryBuild();
			float x = -6+(player_1.Count)*1.0f;
			float z = (player_1.Count)*-0.1f;
			player_1.Add(newCard);
			Vector3 deckPos = GetDeckPosition();
			newCard.transform.position = deckPos;
			newCard.SetDistribution(deckPos,new Vector3(x,-4.5f,z),ShuffleTime,1);

		}
	}

	void DistributePlayer3()
	{
		CardDef c1 = Deck.Pop();
		if (c1 != null)
		{
			GameObject newObj = new GameObject();
			newObj.name = "Card";
			Card newCard = newObj.AddComponent(typeof(Card)) as Card;
			newCard.Definition = c1;
			newObj.transform.parent = Deck.transform;
			BoxCollider bc = newObj.AddComponent<BoxCollider>() as BoxCollider;
			CardClick cc = newObj.AddComponent<CardClick> ();
			bc.center = new Vector3 (0, 0, 0);
			bc.size = new Vector3 (2, 3, 2);
			newCard.TryBuild();
			float x = -3+(player_3.Count)*0.5f;
			float z = (player_3.Count)*-0.1f;
			player_3.Add(newCard);
			Vector3 deckPos = GetDeckPosition();
			newCard.transform.position = deckPos;
			newCard.SetDistribution(deckPos,new Vector3(x,4.5f,z),ShuffleTime,2);

		}
	}

	void DistributePlayer4()
	{
		CardDef c1 = Deck.Pop();
		if (c1 != null)
		{
			GameObject newObj = new GameObject();
			newObj.name = "Card";
			Card newCard = newObj.AddComponent(typeof(Card)) as Card;
			newCard.Definition = c1;
			newObj.transform.parent = Deck.transform;
			BoxCollider bc = newObj.AddComponent<BoxCollider>() as BoxCollider;
			CardClick cc = newObj.AddComponent<CardClick> ();
			bc.center = new Vector3 (0, 0, 0);
			bc.size = new Vector3 (2, 3, 2);
			newCard.TryBuild();
			float y = -3.5f+(player_4.Count)*0.5f;
			float z = (player_4.Count)*-0.1f;
			player_4.Add(newCard);
			Vector3 deckPos = GetDeckPosition();
			newCard.transform.position =deckPos;
			newCard.SetDistribution(deckPos,new Vector3(12.5f,y,z),ShuffleTime,3);

		}
	}

	void DistributePlayer2()
	{
		CardDef c1 = Deck.Pop();
		if (c1 != null)
		{
			GameObject newObj = new GameObject();
			newObj.name = "Card";
			Card newCard = newObj.AddComponent(typeof(Card)) as Card;
			newCard.Definition = c1;
			newObj.transform.parent = Deck.transform;
			BoxCollider bc = newObj.AddComponent<BoxCollider>() as BoxCollider;
			bc.center = new Vector3 (0, 0, 0);
			bc.size = new Vector3 (2, 2, 2);
			CardClick cc = newObj.AddComponent<CardClick> ();
			newCard.TryBuild();
			float y = 3.5f-(player_2.Count)*0.5f;
			float z = (player_2.Count)*-0.1f;
			player_2.Add(newCard);
			Vector3 deckPos = GetDeckPosition();
			//newCard.transform.position = deckPos;
			newCard.SetDistribution(deckPos,new Vector3(-12.5f,y,z),ShuffleTime,4);


		}
	}


	void startGame()
	{
		Card temp;
		if (player_1.Exists (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"))) {
			temp = player_1.Find (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"));
			highest = turn = 1;
			LastCard = temp;
			temp.SetDistribution (temp.transform.position, Position (turn), FlyTime, 1);
			OnPlay.Add (temp);
			player_1.Remove (temp);
		}
		else if (player_2.Exists (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"))) {
			temp = player_2.Find (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"));
			highest =turn = 2;
			LastCard = temp;
			temp.SetDistribution (temp.transform.position, Position(turn), FlyTime, 1);
			OnPlay.Add (temp);
			player_2.Remove (temp);
		}
		else if (player_3.Exists (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"))) {
			temp = player_3.Find (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"));
			highest =turn = 3;
			LastCard = temp;
			temp.SetDistribution (temp.transform.position, Position(turn), FlyTime, 1);
			OnPlay.Add (temp);
			player_3.Remove (temp);
		}
		else if (player_4.Exists (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"))) {
			temp = player_4.Find (x => x.Definition.Symbol.Equals ("Spade") && x.Definition.Text.Equals ("A"));
			highest =turn = 4;
			LastCard = temp;
			temp.SetDistribution (temp.transform.position, Position(turn), FlyTime, 1);
			OnPlay.Add (temp);
			player_4.Remove (temp);
		}
		FirstTurn = false;
		turnCount++;
	}
		
	IEnumerator nextTurn()
	{	
		
		Card[] tempArray;
		Card temp;
		while (true) {
			
			addTurn ();

			List<Card> Player = PlayerTurn (turn);

			if (Player.Count == 0) {
				if (turn == 1) {
					player1Wins.SetActive (true);
				}
				turnCount++;
			}

			else if (turn == 1) {
				YourTurn = true;
				makeVisible ();

				yield return new WaitForSeconds (4.0f);
				ArrangeCard (player_1, 1);
				if (YourTurn)
					turnCount++;
			}

			else if (FirstTurn) {
				tempArray = Player.ToArray ();
				temp = tempArray [Random.Range (0, tempArray.Length)];
				temp.SetDistribution (temp.transform.position, Position (turn), FlyTime, 1);
				Symbol = temp.Definition.Symbol;
				OnPlay.Add (temp);
				Player.Remove (temp);
				turnCount++;
				highest = turn;
				LastCard = temp;
				FirstTurn = false;
			}
				
			else if (Player.Exists (x => x.Definition.Symbol.Equals (Symbol))) { //normal turn
				temp = Player.Find (x => x.Definition.Symbol.Equals (Symbol));
				temp.SetDistribution (temp.transform.position, Position (turn), FlyTime, 1);
				OnPlay.Add (temp);
				Player.Remove (temp);
				turnCount++;
				if (getScore (temp) > getScore (LastCard)) {
					highest = turn;
					LastCard = temp;
				}
			} 

			else {												// thulla turn
				tempArray = Player.ToArray ();
				temp = tempArray [Random.Range (0, tempArray.Length)];
				temp.SetDistribution (temp.transform.position, Position (turn), FlyTime, 1);
				OnPlay.Add (temp);
				Player.Remove (temp);

				yield return new WaitForSeconds (1.5f);
				Card[] PlayCard = OnPlay.ToArray (); 
				for (int i = 0; i < PlayCard.Length ; i++) {
					PlayerTurn(highest).Add (PlayCard [i]);
					OnPlay.Remove (PlayCard [i]);
				}
				ArrangeCard (PlayerTurn (highest), highest);
				turn = highest-1; 
				turnCount=0;
				LastCard = temp;
				FirstTurn = true;
			}

			yield return new WaitForSeconds (1.5f);

			if (turnCount == 4) {
				Card[] PlayCard = OnPlay.ToArray ();
				for (int i = 0; i < PlayCard.Length ; i++) {
					PlayCard [i].SetDistribution (PlayCard[i].transform.position, Position (0), FlyTime, 2);
					yield return new WaitForSeconds (0.2f);
					SpareCard.Add (PlayCard [i]);
					OnPlay.Remove (PlayCard [i]);
				}
				turnCount = 0;
				turn = highest-1;
				FirstTurn = true;
			}


		}

	}

	void addTurn()
	{
		if (turn == 4)
			turn = 0;
		turn++;

	}

	public void DoYourTurn(Card card)
	{
		if (YourTurn) {
			Debug.Log (card.Definition.Text + " of " + card.Definition.Symbol);
			if (player_1.Exists (x => x.Equals (card))) {
				if (FirstTurn) {
					card.SetDistribution (card.transform.position, Position (1), FlyTime, 1);
					Symbol = card.Definition.Symbol;
					OnPlay.Add (card);
					player_1.Remove (card);
					turnCount++;
					highest = turn;
					LastCard = card;
					FirstTurn = false;
					YourTurn = false;
				} else {
					if (card.Definition.Symbol.Equals (Symbol)) {
						card.SetDistribution (card.transform.position, Position (1), FlyTime, 1);
						OnPlay.Add (card);
						player_1.Remove (card);
						turnCount++;
						if (getScore (card) > getScore (LastCard)) {
							highest = turn;
							LastCard = card;
						}
						YourTurn = false;

					} else if (!player_1.Exists (X => X.Definition.Symbol.Equals (Symbol))) {
						card.SetDistribution (card.transform.position, Position (1), FlyTime, 1);
						OnPlay.Add (card);
						player_1.Remove (card);

						//yield return new WaitForSeconds (1.5f);
						Card[] PlayCard = OnPlay.ToArray (); 
						for (int i = 0; i < PlayCard.Length; i++) {
							PlayerTurn (highest).Add (PlayCard [i]);
							OnPlay.Remove (PlayCard [i]);
						}
						ArrangeCard (PlayerTurn (highest), highest);
						turn = highest - 1; 
						turnCount = 0;
						LastCard = card;
						FirstTurn = true;
						YourTurn = false;
					}
				}
			}
		}

	}
	void subTurn()
	{
		turn--;
		if (turn == 0)
			turn = 4;	
	}

	int getScore(Card c)
	{
		if (c.Definition.Pattern == 0) {
			if (c.Definition.Text == "J")
				return 11;
			if (c.Definition.Text == "Q")
				return 12;
			if (c.Definition.Text == "K")
				return 13;
		}
		if (c.Definition.Pattern == 1) {
			return 14;
		}
		return c.Definition.Pattern;
	}

	Vector3 Position(int i)
	{
		if(i == 1 )
			return new Vector3(-2,0,0);
		else if(i == 2 )
			return new Vector3(-1.0f,0,-0.1f);
		else if(i == 3 )
			return new Vector3(0,0,-0.2f);
		else if(i == 4 )
			return new Vector3(1.5f,0,-0.3f);
		
		return new Vector3(-8,0,0);
	}

	List<Card> PlayerTurn(int t)
	{
		if (t == 1)
			return player_1;
		else if (t == 2)
			return player_2;
		else if (t == 3)
			return player_3;
		else if (t == 4)
			return player_4;

		return null;
	}

	void ArrangeCard(List<Card> player, int p)
	{
		if (p == 1) {
			for (int i = 0; i < player.Count; i++) {
				float x = -6 + (i) * 1.0f;
				float z = (i) * -0.1f;
				player[i].SetDistribution (player[i].transform.position, new Vector3 (x, -4.5f, z), ShuffleTime, 1);
			}
		}

		else if (p == 2) {
			for (int i = 0; i < player.Count; i++) {
				float y = 3.5f-(i)*0.5f;
				float z = (i)*-0.1f;
				player[i].SetDistribution (player[i].transform.position, new Vector3(-12.5f,y,z),ShuffleTime,4);
			}
		}

		else if (p == 3) {
			for (int i = 0; i < player.Count; i++) {
				float x = -3+(i)*0.5f;
				float z = (i)*-0.1f;
				player[i].SetDistribution (player[i].transform.position,new Vector3(x,4.5f,z),ShuffleTime,2);
			}
		}

		else if (p == 4) {
			for (int i = 0; i < player.Count; i++) {
				float y = -3.5f+(i)*0.5f;
				float z = (i)*-0.1f;
				player[i].SetDistribution (player[i].transform.position, new Vector3(12.5f,y,z),ShuffleTime,3);
			}
		}
	}

	void makeVisible()
	{
		if (!FirstTurn) {
			Card[] player = player_1.FindAll (x => x.Definition.Symbol.Equals (Symbol)).ToArray();
			for (int i = 0; i < player.Length; i++) {

				Vector3 temp = new Vector3(0,0.8f,0);
				player[i].transform.position += temp;

			}
		}
	}

	public void OnButton(string msg)
	{
		Debug.Log("OnButton = "+msg);

		switch (msg)
		{
		case "Start":
			StartCoroutine(OnStart());
			break;
		}
	}
}
